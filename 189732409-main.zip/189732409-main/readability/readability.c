#include <cs50.h>
#include <ctype.h> // For the isspace(), isalph() functions
#include <math.h>  // For the round() function
#include <stdio.h>
#include <string.h> // For the strlen() function

const float L_MULTIPLIER = 0.0588; // co-efficient of the L value
const float S_MULTIPLIER = 0.296;  // co-efficient of the S value
const float CONSTANT = 15.8;       // The constant value

float coleman_liau_calc(string text);

int main(void)
{
    // Get input from the user of the text
    string text_input = get_string("Text: ");

    // Find the coleman liau index of the given text
    float coleman_liau_value = coleman_liau_calc(text_input);

    // Find the reading age
    int reading_age = (int) round(coleman_liau_value);

    // Print result accordingly
    if (coleman_liau_value >= 1 && coleman_liau_value <= 16)
    {
        printf("Grade %i\n", reading_age);
    }
    else if (coleman_liau_value < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade 16+\n");
    }
}

// coleman-liau index calculator function
float coleman_liau_calc(string text)
{
    int letters = 0;
    int words = 0;
    int sentences = 0;
    int length = strlen(text);

    for (int i = 0; i < length; i++)
    {
        // Calculate total letters
        if isalpha (text[i])
        {
            letters++;
        }

        // Calculate total words
        else if (isspace(text[i]))
        {
            words++; // This is 1 less than total words
        }

        // Calculate total sentences
        else if (text[i] == '!' || text[i] == '.' || text[i] == '?')
        {
            sentences++;
        }
    }
    words++;
    // Calculate the coleman-liau index (cli in this case) and return it
    float cli = L_MULTIPLIER * (((float) letters / words) * 100) -
                S_MULTIPLIER * (((float) sentences / words) * 100) - CONSTANT;
    return cli;
}
