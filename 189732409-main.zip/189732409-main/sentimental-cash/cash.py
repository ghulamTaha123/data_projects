from cs50 import get_float  # import the cs50 library

# repeatedly prompt the user for valid input
while True:
    change = get_float("Change: ")
    if not change < 0:
        break

# work out the change
# loop over until no change remains
change = int((change * 100))
quarters = 25
dimes = 10
nickels = 5
pennies = 1
coins = 0
while change > 0:
    # condition to subtract highest coin type
    if change >= quarters:
        change -= quarters
    elif change >= dimes:
        change -= dimes
    elif change >= nickels:
        change -= nickels
    else:
        change -= pennies
    # incrament coin by 1
    coins += 1

# print number of coins
print(coins)
