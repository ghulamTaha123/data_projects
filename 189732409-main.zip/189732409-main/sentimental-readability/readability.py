# get input from user
text = input("Text: ")

# initialise components of coleman-liau formula
letters = 0
words = 1  # initiased to one since always one more than the space count
sentences = 0

# iterate over text
for c in text:
    if c.isalpha() == True:
        letters += 1
    elif c == " ":
        words += 1
    elif c == "." or c == "!" or c == "?":
        sentences += 1

# work out coleman-liau index
L = (letters / words) * 100  # average number of letters per 100 words
print(L)
S = (sentences / words) * 100  # averege number of sentence per 100 words
print(S)
coleman_liau = 0.0588 * L - 0.296 * S - 15.8
print(coleman_liau)
# print the grade level of that text
if coleman_liau < 1:
    print("Before Grade 1")
elif coleman_liau >= 16:
    print("Grade 16+")
else:
    print("Grade", round(coleman_liau))
