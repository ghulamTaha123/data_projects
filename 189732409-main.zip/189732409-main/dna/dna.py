import csv
import sys


def main():

    # TODO: Check for command-line usage
    if len(sys.argv) != 3:
        print("Missing command-line arguments: filename, STR counts, DNA Sequence")
        sys.exit(1)

    # TODO: Read database file into a variable
    database = []
    with open(sys.argv[1], "r") as file1:
        reader = csv.DictReader(file1)

        # Append the rows to reader
        for row in reader:
            database.append(row)

        # TODO: Read DNA sequence file into a variable
        dna_seq = ""
        with open(sys.argv[2], "r") as file2:
            dna_seq = file2.read()

        # TODO: Find longest match of each STR in DNA sequence
        person = []
        for header in reader.fieldnames[1:]:  # because the first fieldname is the name
            person.append(longest_match(dna_seq, header))

        row_val = []
        # TODO: Check database for matching profiles
        # iterate over the database
        for row in database:
            # create a variable to store the number of successful matches
            succ_str = 0
            # iterate over the dictionary
            for str in range(1, len(row)):
                # if one found

                if (int(row[reader.fieldnames[str]]) == person[str - 1]):
                    # incrament succ_str by 1
                    succ_str += 1

            # if all match
            if (succ_str == len(row) - 1):
                # print name
                print(row[reader.fieldnames[0]])
                return

        # print No match
        print("No match")
        return


def longest_match(sequence, subsequence):
    """Returns length of longest run of subsequence in sequence."""

    # Initialize variables
    longest_run = 0
    subsequence_length = len(subsequence)
    sequence_length = len(sequence)

    # Check each character in sequence for most consecutive runs of subsequence
    for i in range(sequence_length):

        # Initialize count of consecutive runs
        count = 0

        # Check for a subsequence match in a "substring" (a subset of characters) within sequence
        # If a match, move substring to next potential match in sequence
        # Continue moving substring and checking for matches until out of consecutive matches
        while True:

            # Adjust substring start and end
            start = i + count * subsequence_length
            end = start + subsequence_length

            # If there is a match in the substring
            if sequence[start:end] == subsequence:
                count += 1

            # If there is no match in the substring
            else:
                break

        # Update most consecutive matches found
        longest_run = max(longest_run, count)

    # After checking for runs at each character in seqeuence, return longest run found
    return longest_run


main()
