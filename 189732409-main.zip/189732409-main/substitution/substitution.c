#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int check_alph(string key, int key_length);
int check_repeated(string key, int key_length);
string encipher_function(string key, string plaintext, int key_length, int text_length);
string turn_upper(string key, int key_length);

int main(int argc, string argv[]) // argv is the key
{
    if (argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }

    const int key_length = strlen(argv[1]);
    string key =
        turn_upper(argv[1], key_length); // the key is made all uppercase for ease to processing

    // Validate key

    // Check if the key contains 26 characters
    if (key_length == 26)
    {
        // Check if all characters are alphabetical
        if (check_alph(key, key_length))
        {
            // Check for repeated characters
            if (check_repeated(key, key_length))
            {
                // Run the rest of the code

                // Get plaintext
                string plaintext = get_string("plaintext: ");
                int text_length = strlen(plaintext);

                // Encipher the text and print it
                string cipher_text = encipher_function(key, plaintext, key_length, text_length);
                printf("ciphertext: %s\n", cipher_text);
            }
            else
            {
                printf("Key must not contain repeated characters.\n");
                return 1;
            }
        }
        else
        {
            printf("Key must only contain alphabatic characters.\n");
            return 1;
        }
    }
    else
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
}

// Function to check if key is alphabetical
int check_alph(string key, int key_length)
{
    for (int i = 0; i < key_length; i++)
    {
        if (isalpha(key[i]))
        {
            continue;
        }
        else
        {
            return 0;
        }
    }
    return 1;
}

// Function to check for repeated characters
int check_repeated(string key, int key_length)
{
    for (int i = 0; i < key_length; i++)
    {
        for (int j = i + 1; j < key_length; j++)
        {
            if (key[i] != key[j])
            {
                continue;
            }
            else
            {
                return 0;
            }
        }
    }
    return 1;
}

// To change the key to all uppercase
string turn_upper(string key, int key_length)
{
    for (int i = 0; i < key_length; i++)
    {
        if (islower(key[i]))
        {
            key[i] = toupper(key[i]);
        }
    }
    return key;
}

// The encipher function
string encipher_function(string key, string plaintext, int key_length, int text_length)
{
    // Create an array of normal alphabets
    char alphabets[key_length];
    for (int i = 0; i < key_length; i++)
    {
        alphabets[i] = 'A' + i;
    }

    // Map the plaintext to ciphertext
    for (int i = 0; i < text_length; i++)
    {
        if (isalpha(plaintext[i]))
        {
            for (int j = 0; j < key_length; j++)
            {
                if (plaintext[i] == alphabets[j])
                {
                    plaintext[i] = key[j];
                    break;
                }
                else if (plaintext[i] == tolower(alphabets[j]))
                {
                    plaintext[i] = tolower(key[j]);
                    break;
                }
            }
        }
    }
    return plaintext;
}
