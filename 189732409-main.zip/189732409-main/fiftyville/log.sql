-- Keep a log of any SQL queries you execute as you solve the mystery.
.tables -- to view all the tables in order to search through them

-- Looking at the schema of all the tables
.schema tableX

 -- occasionally doing this to get the general outlook of each table
 SELECT *
   FROM tablex
  LIMIT 10;

-- To get the desciptions of the crime scenes that happened on the pertinent date
sqlite> SELECT description
   ...>   FROM crime_scene_reports
   ...>  WHERE day = 28
   ...>    AND month = 7
   ...>    AND year = 2024
   ...>    AND street = 'Humphrey Street';
/* Theft of the CS50 duck took place at 10:15am at the Humphrey Street bakery.
Interviews were conducted today with three witnesses who were present at the time – each of their interview transcripts mentions the bakery.*/

-- to see what was happening at the time near 10:15, id 258 to 265 likely, most likely 260 and 261
SELECT * FROM bakery_security_logs WHERE month = 7 AND day = 28 AND hour = 10;
   +-----+------+-------+-----+------+--------+----------+---------------+
| id  | year | month | day | hour | minute | activity | license_plate |
+-----+------+-------+-----+------+--------+----------+---------------+
| 260 | 2024 | 7     | 28  | 10   | 16     | exit     | 5P2BI95       |
| 261 | 2024 | 7     | 28  | 10   | 18     | exit     | 94KL13X       |
| 262 | 2024 | 7     | 28  | 10   | 18     | exit     | 6P58WS2       |
| 263 | 2024 | 7     | 28  | 10   | 19     | exit     | 4328GD8       |
| 264 | 2024 | 7     | 28  | 10   | 20     | exit     | G412CB7       |
| 265 | 2024 | 7     | 28  | 10   | 21     | exit     | L93JTIZ       |
| 266 | 2024 | 7     | 28  | 10   | 23     | exit     | 322W7JE       |
| 267 | 2024 | 7     | 28  | 10   | 23     | exit     | 0NTHK55       |

-- to see what the witensses said
SELECT *
  FROM interviews
 WHERE month = 7
   AND day = 28;
/*| 161 | Ruth    | 2024 | 7     | 28  | Sometime within ten minutes of the theft, I saw the thief get into a car
 in the bakery parking lot and drive away. If you have security footage from the bakery parking lot, you might want
  to look for cars that left the parking lot in that time frame.|
| 162 | Eugene  | 2024 | 7     | 28  | I don't know the thief's name, but it was someone I recognized. Earlier this
morning, before I arrived at Emma's bakery, I was walking by the ATM on Leggett Street and saw the thief there withdrawing some money.                                                                                                 |
| 163 | Raymond | 2024 | 7     | 28  | As the thief was leaving the bakery, they called someone who talked to them for
less than a minute. In the call, I heard the thief say that they were planning to take the earliest flight out of Fiftyville tomorrow.
The thief then asked the person on the other end of the phone to purchase the flight ticket. |*/

-- to see the transactions before 10:15
SELECT * FROM atm_transactions WHERE year = 2024 AND month = 7 AND day = 28 AND atm_location = 'Leggett Street';
+-----+----------------+------+-------+-----+----------------+------------------+--------+
| id  | account_number | year | month | day |  atm_location  | transaction_type | amount |
+-----+----------------+------+-------+-----+----------------+------------------+--------+
| 246 | 28500762       | 2024 | 7     | 28  | Leggett Street | withdraw         | 48     |
| 264 | 28296815       | 2024 | 7     | 28  | Leggett Street | withdraw         | 20     |
| 266 | 76054385       | 2024 | 7     | 28  | Leggett Street | withdraw         | 60     |
| 267 | 49610011       | 2024 | 7     | 28  | Leggett Street | withdraw         | 50     |
| 269 | 16153065       | 2024 | 7     | 28  | Leggett Street | withdraw         | 80     |
| 288 | 25506511       | 2024 | 7     | 28  | Leggett Street | withdraw         | 20     |
| 313 | 81061156       | 2024 | 7     | 28  | Leggett Street | withdraw         | 30     |
| 336 | 26013199       | 2024 | 7     | 28  | Leggett Street | withdraw         | 35     |
+-----+----------------+------+-------+-----+----------------+------------------+--------+


-- To get the call logs for the day
SELECT * FROM phone_calls WHERE year = 2024 AND month = 7 AND day = 28 AND duration < 60;
+-----+----------------+----------------+------+-------+-----+----------+
| id  |     caller     |    receiver    | year | month | day | duration |
+-----+----------------+----------------+------+-------+-----+----------+
| 221 | (130) 555-0289 | (996) 555-8899 | 2024 | 7     | 28  | 51       |
| 224 | (499) 555-9472 | (892) 555-8872 | 2024 | 7     | 28  | 36       |
| 233 | (367) 555-5533 | (375) 555-8161 | 2024 | 7     | 28  | 45       |
| 251 | (499) 555-9472 | (717) 555-1342 | 2024 | 7     | 28  | 50       |
| 254 | (286) 555-6063 | (676) 555-6554 | 2024 | 7     | 28  | 43       |
| 255 | (770) 555-1861 | (725) 555-3243 | 2024 | 7     | 28  | 49       |
| 261 | (031) 555-6622 | (910) 555-3251 | 2024 | 7     | 28  | 38       |
| 279 | (826) 555-1652 | (066) 555-9701 | 2024 | 7     | 28  | 55       |
| 281 | (338) 555-6650 | (704) 555-2131 | 2024 | 7     | 28  | 54       |
+-----+----------------+----------------+------+-------+-----+----------+

-- to find the earliest flight the next day
SELECT * FROM flights WHERE year = 2024 AND month = 7 AND day = 29;
| 36 | 8                 | 4                      | 2024 | 7     | 29  | 8    | 20     |

-- to find out which city they escaped to
SELECT city FROM airports WHERE id = 4;
+---------------+
|     city      |
+---------------+
| New York City |
+---------------+

-- to get the passport_numbers of all the people in flight with id 36
SELECT * FROM passengers WHERE flight_id = 36;
+-----------+-----------------+------+
| flight_id | passport_number | seat |
+-----------+-----------------+------+
| 36        | 7214083635      | 2A   |
| 36        | 1695452385      | 3B   |
| 36        | 5773159633      | 4A   |
| 36        | 1540955065      | 5C   |
| 36        | 8294398571      | 6C   |
| 36        | 1988161715      | 6D   |
| 36        | 9878712108      | 7A   |
| 36        | 8496433585      | 7B   |
+-----------+-----------------+------+

-- to get the id of the person who made the atm_trasaction
SELECT person_id FROM bank_account WHERE account_number IN (SELECT account_number FROM atm_transactions WHERE year = 2024 AND month = 7 AND day = 28 AND atm_location = 'Leggett Street');

-- the final querie to find the thief
SELECT DISTINCT people.name, people.phone_number, passengers.passport_number
FROM phone_calls INNER JOIN bakery_security_logs ON
bakery_security_logs.year = phone_calls.year AND bakery_security_logs.month = phone_calls.month AND bakery_security_logs.day = phone_calls.day
INNER JOIN people ON people.license_plate = bakery_security_logs.license_plate
INNER JOIN passengers ON people.passport_number = passengers.passport_number
WHERE passengers.flight_id = 36 AND bakery_security_logs.year = 2024 AND bakery_security_logs.month = 7 AND bakery_security_logs.day = 28
AND passengers.passport_number IN
(SELECT passport_number FROM passengers WHERE flight_id = 36)
AND people.phone_number IN (SELECT caller FROM phone_calls WHERE year = 2024 AND month = 7 AND day = 28 AND duration < 60)
AND people.license_plate IN (SELECT license_plate FROM bakery_security_logs WHERE month = 7 AND day = 28 AND hour = 10 AND minute >= 15 AND minute <= 25 AND activity = 'exit')
AND people.id IN (SELECT person_id FROM bank_accounts WHERE account_number IN
(SELECT account_number FROM atm_transactions WHERE year = 2024 AND month = 7 AND day = 28 AND atm_location = 'Leggett Street' AND transaction_type = 'withdraw'));
-- I got the thief as being bruce

-- to get the accomplice
SELECT name FROM people WHERE phone_number = '(375) 555-8161';
-- got accomplice as being robin
