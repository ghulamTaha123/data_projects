# get user's name
name = input("What is your name? ")

# say hello to user
print("Hello", name)

