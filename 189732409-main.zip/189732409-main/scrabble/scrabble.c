#include <cs50.h>
#include <ctype.h> // for the tolower() function
#include <stdio.h>
#include <string.h> // for hte strlen() function

int calc_score(string word, int score[]);
string to_lowercase(string word);

#define TOTAL_ALPHABETS 26

int main(void)
{
    // Create score array
    int score[TOTAL_ALPHABETS] = {1, 3, 3, 2,  1, 4, 2, 4, 1, 8, 5, 1, 3,
                                  1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

    // Get input from player1 and turn to lowercase
    string player1_word = to_lowercase(get_string("Player 1: "));

    // Get input from player2 and turn to lowercase
    string player2_word = to_lowercase(get_string("Player 2: "));

    // Check player1 score
    int player1_score = calc_score(player1_word, score);
    // Check player2 score
    int player2_score = calc_score(player2_word, score);

    // Compare player1 and player2 inputs and print who won/tied
    if (player1_score > player2_score)
    {
        printf("Player 1 wins!");
    }
    else if (player1_score < player2_score)
    {
        printf("Player 2 wins!");
    }
    else
    {
        printf("Tie!");
    }
    printf("\n");
}

// Turn to lower case function
string to_lowercase(string word)
{
    for (int i = 0, length = strlen(word); i < length;
         i++) // iterate through the loop and turn each element to lowercase
    {
        word[i] = tolower(word[i]);
    }
    return word;
}

// calculate_score function
int calc_score(string word, int score[])
{
    int score_total = 0;
    for (int i = 0, word_length = strlen(word); i < word_length; i++)
    {
        if ('a' <= word[i] && word[i] <= 'z')
        {
            score_total += score[word[i] - 'a']; // accesses the ascii chart directly
        }
        else
        {
            continue; // so that characters other than the alphabets are accounted for
        }
    }
    return score_total;
}
