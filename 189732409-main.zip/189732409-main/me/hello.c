#include <cs50.h> // Importing the cs50 library
#include <stdio.h>

int main(void)
{
    string name = get_string("What is your name?\n"); // Get input from the user.
    printf("Hello, %s\n", name);                      // Print the user input (name)
}
