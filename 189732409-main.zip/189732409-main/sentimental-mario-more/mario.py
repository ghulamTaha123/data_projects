from cs50 import get_int # import the cs50 library

# repeated promt user for valid input
min_height = 1
max_height = 8
while True:
    height = get_int("Enter pyramid height: ")
    if (height >= min_height and height <= max_height):
        break

# print the pyramids
for i in range(height):
    # print spaces
    for j in range(height - (i + 1)):
        print(" ", end="")
    # print hashes
    for j in range(i + 1):
        print("#", end="")
    # print the gap
    print("  ", end="")
    # print the hashes second pyramid
    for j in range((i + 1)):
        print("#", end="")
    # print a new line
    print()
