// Modifies the volume of an audio file

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

// Number of bytes in .wav header
const int HEADER_SIZE = 44;

int main(int argc, char *argv[])
{
    // Check command-line arguments
    if (argc != 4)
    {
        printf("Usage: ./volume input.wav output.wav factor\n");
        return 1;
    }

    // Open files and determine scaling factor
    FILE *input = fopen(argv[1], "r");
    if (input == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    FILE *output = fopen(argv[2], "w");
    if (output == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    float factor = atof(argv[3]);

    // TODO: Copy header from input file to output file

    // Create a buffer to store the read header
    uint8_t buffer[HEADER_SIZE];

    if (fread(buffer, sizeof(uint8_t), HEADER_SIZE, input) != // Store the header in a buffer
        fwrite(buffer, sizeof(uint8_t), HEADER_SIZE,
               output)) // Write the header from the buffer into the output
    {
        printf(
            "Error! Successeful read not equal to successful write\n"); /* Handle error if read
                                                                           and written not equal */
        return 1;
    }

    // TODO: Read samples from input file and write updated data to output file

    // Create a buffer to read each sample
    int16_t samp_buffer;

    // Read each element of the buffer
    while (fread(&samp_buffer, sizeof(int16_t), 1, input) != 0)
    {
        samp_buffer *= factor; // Increase the size of the element of the buffer
        fwrite(&samp_buffer, sizeof(int16_t), 1, output); // Write to the output
    }

    // Close files
    fclose(input);
    fclose(output);
}
