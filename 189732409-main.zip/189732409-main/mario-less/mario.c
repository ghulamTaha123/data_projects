// The purpose is to print double pyramids with two bricks worth of spaces depending on user's input

#include <cs50.h> // Import the cs50 library
#include <stdio.h>

#define MIN_HEIGHT 1
#define MAX_HEIGHT 8

void print_pyramid_row(int spaces, int length); // Function to print a row of '#'

int main(void)
{
    int height;
    do // Repeatedly prompt the user for height
    {
        height = get_int("Height: ");
    }
    while (height < MIN_HEIGHT || height > MAX_HEIGHT);

    for (int i = 0; i < height; i++) // To print the coloums
    {
        print_pyramid_row(height - (i + 1), i); // height - (i + 1) is the number of spaces
                                                // i is the length
        printf("\n");
    }
}

// Function to print the pyramid row
void print_pyramid_row(int spaces, int length)
{
    for (int i = spaces; i > 0; i--)
    {
        printf(" "); // To print spaces
    }
    for (int i = 0; i < length + 1; i++)
    {
        printf("#"); // To print '#'s
    }
}
