// Implements a dictionary's functionality

#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 143093;

// Number of words in dictionary
unsigned int words_tot;

// Hash table
node *table[N];

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    // variable to keep track of word amount
    int num_words = 0;

    // Initialize all table values to NULL
    for (int i = 0; i < N; i++)
    {
        table[i] = NULL;
    }

    // Open the dictionary file
    FILE *source = fopen(dictionary, "r");

    if (source == NULL)
    {
        printf("not able to open dictionary");
        return false;
    }

    // Read each word in the file
    char word_in[LENGTH + 1];
    while (fscanf(source, "%s", word_in) != EOF)
    {
        unsigned int hash_code = hash(word_in);

        // Add each word to the hash table
        node *n = malloc(sizeof(node));

        if (n == NULL)
        {
            printf("not able to allocate memory for node");
            return false;
        }

        // Copy word into n's word field
        strcpy(n->word, word_in);
        n->next = NULL;

        // Check if node already exists
        if (table[hash_code] == NULL)
        {
            // Set array index to n
            table[hash_code] = n;
        }
        else
        {
            // Prepend node to array pointer
            n->next = table[hash_code];
            table[hash_code] = n;
        }

        // Incrament number of words
        num_words++;
    }
    // Close the dictionary file
    fclose(source);

    // Update words_tot global variable
    words_tot = num_words;

    return true;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // Use a polynomial rolling hash function
    int n = 31; // constant value to raise to power, and then multiple ascii values by
    int i = 0;
    unsigned int sum = 0;
    while (word[i] != '\0')
    {
        sum += (tolower(word[i]) * (int) pow(n, i));
        i++;
    }

    return (sum %= N);
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    return words_tot;
}

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // get the hash code
    unsigned int hash_code = hash(word);

    // Iterate through linked list and compare strings until null
    for (node *ptr = table[hash_code]; ptr != NULL; ptr = ptr->next)
    {
        // If word found return true
        if (strcasecmp(word, ptr->word) == 0) // compare case insensitively
        {
            return true;
        }
    }

    // If word not found return false
    return false;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // Iterate over the indices of the hash table
    for (int i = 0; i < N; i++)
    {
        // If index is not NULL
        if (table[i] != NULL)
        {
            // iterate over the linked list
            node *trv = table[i];
            while (trv != NULL)
            {
                node *next = trv->next;

                // free node
                free(trv);
                trv = next;
            }
        }
    }
    return true;
}
