#include "helpers.h"
#include <math.h>
#include <stdio.h>

const int MATRIX_SIZE = 3;
const int TOTCOLOURS = 3;

int apply_sobel(int sub_array[MATRIX_SIZE][MATRIX_SIZE]);
RGBTRIPLE average_pixel(int height, int width, RGBTRIPLE image[height][width], int curr_row,
                        int curr_pixel);
void copy_image(int height, int width, RGBTRIPLE image[height][width],
                RGBTRIPLE copy[height][width]);

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    // For every row in the image
    for (int i = 0; i < height; i++)
    {
        // For every pixel in row
        for (int j = 0; j < width; j++)
        {
            // Find the average intensity of the three colours
            float colour_average =
                (image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed) /
                (float) TOTCOLOURS;
            colour_average = (int) round(colour_average);

            // Set each colour to the average
            image[i][j].rgbtBlue = colour_average;
            image[i][j].rgbtGreen = colour_average;
            image[i][j].rgbtRed = colour_average;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    // Temporary variable to store current pixel
    RGBTRIPLE temp;

    // For every row
    for (int i = 0; i < height; i++)
    {
        // Swap the corresponding distant pixels
        for (int j = 0; j < width / 2; j++)
        {
            temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // Create a temporary copy of image to store the average values so the input image isn't
    // tampered with
    RGBTRIPLE image_copy[height][width];
    copy_image(height, width, image, image_copy);

    // Iterate through each pixel in each row
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // Average the adjacent pixels
            image_copy[i][j] = average_pixel(height, width, image, i, j);
        }
    }

    // Fill the orignal image with the values in the copy
    copy_image(height, width, image_copy, image);

    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    // Create a temporary copy of the image to store final sobel values so the original image isn't
    // tampered with
    RGBTRIPLE image_copy[height][width];
    copy_image(height, width, image, image_copy);

    // Iterate over rows
    for (int i = 0; i < height; i++)
    {
        // Iterate over pixels
        for (int j = 0; j < width; j++)
        {
            // Iterate over each channel
            for (int k = 0; k < TOTCOLOURS; k++)
            {
                // Create sub array at current pixel
                int sub_array[MATRIX_SIZE][MATRIX_SIZE];
                for (int l = i - 1; l <= i + 1; l++)
                {
                    for (int m = j - 1; m <= j + 1; m++)
                    {
                        if (k == 0)
                        {
                            if (l < height && m < width && l >= 0 && m >= 0)
                            {
                                sub_array[l - i + 1][m - j + 1] =
                                    image[l][m].rgbtRed; // since the sub_array is a 3x3
                            }
                            else
                            {
                                sub_array[l - i + 1][m - j + 1] = 0;
                            }
                        }
                        else if (k == 1)
                        {
                            if (l < height && m < width && l >= 0 && m >= 0)
                            {
                                sub_array[l - i + 1][m - j + 1] = image[l][m].rgbtGreen;
                            }
                            else
                            {
                                sub_array[l - i + 1][m - j + 1] = 0;
                            }
                        }
                        else if (k == 2)
                        {
                            if (l < height && m < width && l >= 0 && m >= 0)
                            {
                                sub_array[l - i + 1][m - j + 1] = image[l][m].rgbtBlue;
                            }
                            else
                            {
                                sub_array[l - i + 1][m - j + 1] = 0;
                            }
                        }
                    }
                }

                // Set corresponding colour at pixel i,j to final sobel value
                if (k == 0)
                {
                    image_copy[i][j].rgbtRed = apply_sobel(sub_array);
                }
                else if (k == 1)
                {
                    image_copy[i][j].rgbtGreen = apply_sobel(sub_array);
                }
                else if (k == 2)
                {
                    image_copy[i][j].rgbtBlue = apply_sobel(sub_array);
                }
            }
        }
    }

    // Fill the orignal image with the values in the copy
    copy_image(height, width, image_copy, image);

    return;
}

// Copy image function
void copy_image(int height, int width, RGBTRIPLE image[height][width],
                RGBTRIPLE copy[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            copy[i][j] = image[i][j];
        }
    }
}

// Average function
RGBTRIPLE average_pixel(int height, int width, RGBTRIPLE image[height][width], int curr_row,
                        int curr_pixel) // i, j are row and pixel numbers respectively
{
    // Initialise variables
    int adjacent_pixels = 0;
    int blue_sum = 0;
    int green_sum = 0;
    int red_sum = 0;
    RGBTRIPLE average;

    // For every row
    for (int i = curr_row - 1; i <= curr_row + 1; i++)
    {
        // for every pixel within the row
        for (int j = curr_pixel - 1; j <= curr_pixel + 1; j++)
        {
            // Sum curr_pixel's and adjacent pixel's rbg values
            if (i < height && j < width && i >= 0 && j >= 0)
            {
                blue_sum += image[i][j].rgbtBlue;
                green_sum += image[i][j].rgbtGreen;
                red_sum += image[i][j].rgbtRed;
                adjacent_pixels++;
            }
        }
    }

    // Find average of adjacent colours
    average.rgbtBlue = (int) round(blue_sum / ((float) adjacent_pixels));
    average.rgbtGreen = (int) round(green_sum / ((float) adjacent_pixels));
    average.rgbtRed = (int) round(red_sum / ((float) adjacent_pixels));

    return average;
}

// Applies the sobel algorithm
int apply_sobel(int sub_array[MATRIX_SIZE][MATRIX_SIZE])
{
    // Initialise the variables
    const int MAX_INTENSITY = 255;
    const int MIN_INTENSITY = 0;
    int weighted_sum_x = 0;
    int weighted_sum_y = 0;
    int final_value;

    const int Gx[MATRIX_SIZE][MATRIX_SIZE] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}}; // Define Gx
    const int Gy[MATRIX_SIZE][MATRIX_SIZE] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}}; // Define Gy

    // Find the weighted sum for Gx and Gy
    for (int i = 0; i < MATRIX_SIZE; i++)
    {
        for (int j = 0; j < MATRIX_SIZE; j++)
        {
            weighted_sum_x += (sub_array[i][j] * Gx[i][j]);
            weighted_sum_y += (sub_array[i][j] * Gy[i][j]);
        }
    }

    // Find final value
    final_value = (int) round(sqrt(pow(weighted_sum_x, 2) + pow(weighted_sum_y, 2)));

    // Cap final value
    if (final_value > MAX_INTENSITY)
    {
        final_value = MAX_INTENSITY;
    }
    else if (final_value < 0)
    {
        final_value = MIN_INTENSITY;
    }

    return final_value;
}
