#include <cs50.h>
#include <stdio.h>

int calculate_coin_num(int cents);

int main(void)
{
    // Repeatedly promt user for positive integer input.
    int cents;
    do
    {
        cents = get_int("Change owed: ");
    }
    while (cents < 0);

    int coin_num = calculate_coin_num(cents);
    printf("%i\n", coin_num);
}

// Function to calculate the coins of each type to be returned
int calculate_coin_num(int cents)
{
    // Initialize each type of variable to 0
    int quarters = 0;
    int dimes = 0;
    int nickels = 0;
    int pennies = 0;

    // Calculate you many coins of a certian type to return
    // Calculate the change left over

    while (cents > 0)
    {
        // To calculate number of quarters
        if (cents >= 25)
        {
            quarters = cents / 25;
            cents %= 25;
        }

        // To calculate number of dimes
        else if (cents >= 10 && cents < 25)
        {
            dimes = cents / 10;
            cents %= 10;
        }

        // To calculate number of nickels
        else if (cents >= 5 && cents < 10)
        {
            nickels = cents / 5;
            cents %= 5;
        }

        // To calculate number of pennies
        else if (cents >= 0 && cents < 5)
        {
            pennies = cents;
            cents = 0;
        }
    }
    return quarters + dimes + nickels + pennies;
}
