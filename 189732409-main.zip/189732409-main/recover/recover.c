#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

const int block_size = 512;
const int filename_length = 8; // ###.jpg/0

int main(int argc, char *argv[])
{
    // Accept a single command-line argument
    if (argc != 2)
    {
        printf("Usage: ./recover FILE\n");
        return 1;
    }

    // Open the memory card
    FILE *card = fopen(argv[1], "r");

    // Check case of card not opening
    if (card == NULL)
    {
        printf("Forensic image couldn't be opened.\n");
        return 1;
    }

    // allocate memory to store the filenames
    char *filename = malloc(filename_length);
    if (filename == NULL)
    {
        printf("Unable to allocate memory for filename\n");
        return 2;
    }

    // Declare the image pointer where each jpeg will located
    FILE *image = NULL;

    // Create a buffer to store a block of data
    uint8_t buffer[block_size];

    // initialise total JPEGs
    int jpeg_count = 0; // staring at 0

    // Repeat until end of card
    int byte_size = sizeof(uint8_t);
    while (fread(buffer, byte_size, block_size, card) == block_size) // read 512 bytes
                                                                     // into a buffer
    {
        // if start of new JPEG
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff &&
            (buffer[3] & 0xf0) == 0xe0)
        {
            // if first JPEG, write to it
            if (jpeg_count == 0)
            {
                // print the jpeg_count to filename
                sprintf(filename, "%03i.jpg", jpeg_count);

                // create a new file and write
                image = fopen(filename, "w");

                if (image == NULL)
                {
                    fclose(card);
                    free(filename);
                    printf("Unable to open first JPEG\n");
                    return 3;
                }

                // write to file
                fwrite(buffer, byte_size, block_size, image);

                // increase the number of JPEGs found by 1
                jpeg_count++;
            }
            else
            {
                // close previous file and open new one
                fclose(image);

                // print the jpeg_count to filename
                sprintf(filename, "%03i.jpg", jpeg_count);

                // create a new file and write
                image = fopen(filename, "w");

                if (image == NULL)
                {
                    fclose(card);
                    free(filename);
                    printf("Unable to open a JPEG\n");
                    return 4;
                }

                // write to file
                fwrite(buffer, byte_size, block_size, image);

                // increase the number of JPEGs found by 1
                jpeg_count++;
            }
        }
        else
        {
            // keep writing to the current jpeg
            if (image != NULL)
            {
                fwrite(buffer, byte_size, block_size, image);
            }
        }
    }
    // Close remaining files
    fclose(image);
    fclose(card);

    // Free allocated memory
    free(filename);
}
