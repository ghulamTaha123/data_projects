#include <cs50.h>
#include <math.h>
#include <stdio.h>

int get_length(long long number);
int calc_checksum(long long number, int length);
int calc_stardig(long long number, int length);

int main(void)
{
    // Prompt for input
    long long number = get_long("Enter a number: ");

    // Calculate length of number
    int length = get_length(number);

    // Calculate checksum
    int checksum = calc_checksum(number, length);

    // Calculate starting digits
    int starting_digits = calc_stardig(number, length);

    // Print AMEX, MASTERCARD, VISA or INVALID
    if (checksum % 10 == 0)
    {
        if (length == 15 && (starting_digits == 34 || starting_digits == 37))
        {
            printf("AMEX\n");
        }
        else if (length == 16 &&
                 (starting_digits == 51 || starting_digits == 52 || starting_digits == 53 ||
                  starting_digits == 54 || starting_digits == 55))
        {
            printf("MASTERCARD\n");
        }
        else if ((length == 13 || length == 16) && (starting_digits / 10 == 4))
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
}

// find length function
int get_length(long long number)
{
    int i = 0;
    while (number != 0)
    {
        number /= 10; // to terminate the last digit
        i++;
    }

    // return i
    return i;
}

// Create checksum function
int calc_checksum(long long number, int length)
{
    // initialze variables luhn1_sum (first part of luhn's), luhn2_sum (second part of luhn's),
    // digit to 0
    int luhn1_sum = 0, luhn2_sum = 0, digit = 0;

    // Find Luhn's algorithm
    // for i less than length
    for (int i = 0; i < length; i++)
    {
        // Work out each digit
        digit = number % 10;

        // calculate first half of luhn's algorithm (luhn1_sum)
        // if i % 2 is 1: locate the second last digit
        if ((i % 2) == 1)
        {
            // multiple digit by 2
            digit *= 2;

            // if digit greater than 10
            if (digit >= 10)
            {
                // find the sum of digits
                digit = (digit % 10) + (digit / 10);
            }

            // find luhn1_sum
            luhn1_sum += digit;
        }

        // else
        else
        {
            // find luhn2_sum
            luhn2_sum += digit;
        }

        // remove last digit each iteration
        number /= (10);
    }

    // return total
    return luhn1_sum + luhn2_sum;
}

// calculate starting digits
int calc_stardig(long long number, int length)
{
    // keep dividng by 10 until 2 digits left
    for (int i = 0; i < length - 2; i++)
    {
        number /= 10;
    }

    // return number
    return number;
}
